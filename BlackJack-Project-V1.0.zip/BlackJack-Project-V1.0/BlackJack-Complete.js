var p1bet = 0;
var p2bet = 0;
var p3bet = 0;
var p1Pot = 100;
var p2Pot = 100;
var p3Pot = 100;
var deckInUse = [];
var newDeck = [];
var outTheDeck = [];
var p1betTotal = document.querySelector('.p1BetTotal');
var p1potTotal = document.querySelector('.p1Pot');
var p2betTotal = document.querySelector('.p2BetTotal');
var p2potTotal = document.querySelector('.p2Pot');
var p3betTotal = document.querySelector('.p3BetTotal');
var p3potTotal = document.querySelector('.p3Pot');
var p3Card1 = document.querySelector('.p3Card1');
var p3Card2 = document.querySelector('.p3Card2');
var p3Card3 = document.querySelector('.p3Card3');
var p3Card4 = document.querySelector('.p3Card4');
var p3Card5 = document.querySelector('.p3Card5');
var p3Card6 = document.querySelector('.p3Card6');
var p3Card7 = document.querySelector('.p3Card7');
var p3Card8 = document.querySelector('.p3Card8');
var p2Card1 = document.querySelector('.p2Card1');
var p2Card2 = document.querySelector('.p2Card2');
var p2Card3 = document.querySelector('.p2Card3');
var p2Card4 = document.querySelector('.p2Card4');
var p2Card5 = document.querySelector('.p2Card5');
var p2Card6 = document.querySelector('.p2Card6');
var p2Card7 = document.querySelector('.p2Card7');
var p2Card8 = document.querySelector('.p2Card8');
var p1Card1 = document.querySelector('.p1Card1');
var p1Card2 = document.querySelector('.p1Card2');
var p1Card3 = document.querySelector('.p1Card3');
var p1Card4 = document.querySelector('.p1Card4');
var p1Card5 = document.querySelector('.p1Card5');
var p1Card6 = document.querySelector('.p1Card6');
var p1Card7 = document.querySelector('.p1Card7');
var p1Card8 = document.querySelector('.p1Card8');
var dCard1 = document.querySelector('.dCard1');
var dCard2 = document.querySelector('.dCard2');
var dCard3 = document.querySelector('.dCard3');
var dCard4 = document.querySelector('.dCard4');
var dCard5 = document.querySelector('.dCard5');
var dCard6 = document.querySelector('.dCard6');
var dCard7 = document.querySelector('.dCard7');
var dCard8 = document.querySelector('.dCard8');
var p3CardTotal = document.querySelector('.p3CardTotal');
var p2CardTotal = document.querySelector('.p2CardTotal');
var p1CardTotal = document.querySelector('.p1CardTotal');
var dCard1 = document.querySelector('.dCard1');
var dCard2 = document.querySelector('.dCard2');
var dValue = document.querySelector('.dValue');
var shoe = document.querySelector('.shoe');
var p3BetBtn = document.querySelector('.p3BetBtn');
var count = '';
var countTrack = document.querySelector('.count');
var p1Status = false;
var p2Status = false;
var p3Status = false;
document.getElementById("p1DoubleBtn").disabled = true;
    document.getElementById("p1StandBtn").disabled = true;
    document.getElementById("p1HitBtn").disabled = true;
    document.getElementById("p2DoubleBtn").disabled = true;
    document.getElementById("p2StandBtn").disabled = true;
    document.getElementById("p2HitBtn").disabled = true;
    document.getElementById("p3DoubleBtn").disabled = true;
    document.getElementById("p3StandBtn").disabled = true;
    document.getElementById("p3HitBtn").disabled = true;
    document.getElementById("shuffleBtn").disabled = true;
dTotal = 0;
function p1bet5(){
    if (p1Pot > 0){
        p1Pot -= 5;
        p1bet += 5;
    } else {
        alert("You're Out of Chips!");
    }
    document.getElementById("clear").disabled = true;
    p1betTotal.innerText = 'Bet: ' + p1bet;
    p1potTotal.innerText = 'Pot: ' + p1Pot;
}
function p2bet5(){
    if (p2Pot > 0){
        p2Pot -= 5;
        p2bet += 5;
    } else {
        alert("You're Out of Chips!");
    }
    document.getElementById("clear").disabled = true;
    p2betTotal.innerText = 'Bet: ' + p2bet;
    p2potTotal.innerText = 'Pot: ' + p2Pot;
}
function p3bet5(){
    if (p3Pot > 0){
        p3Pot -= 5;
        p3bet += 5;
    } else {
        alert("You're Out of Chips!");
    }
    document.getElementById("clear").disabled = true;
    p3betTotal.innerText = 'Bet: ' + p3bet;
    p3potTotal.innerText = 'Pot: ' + p3Pot;;
}
function numberOfplayers(){
    var numOfPlayers = 0;
    if(p1bet > 0){
        numOfPlayers++;
    }
    if(p2bet > 0){
        numOfPlayers++;
    }
    if(p3bet > 0){
        numOfPlayers++;
    } return numOfPlayers;
}
function deckOfCards(){
    var suits=['H','S','C','D'];
    var rank=['2','3','4','5','6','7','8','9','10','10J','10Q','10K','11A'];
    var deck=[];
    for(var i=0;i<suits.length;i++){
    for (var z=0;z<rank.length;z++){
        deck.push(rank[z]+suits[i]);
        }
    } return deck;
}
var deck = deckOfCards();
var playingDeck = [];
for(var q=0;q<6;q++){
    for (var t=0;t<deck.length;t++){
        playingDeck.push(deck[t]);
    }
}
function randomizer(){
let unshuffled = playingDeck;
let shuffled = unshuffled
    .map(value => ({ value, sort: Math.random() }))
    .sort((a, b) => a.sort - b.sort)
    .map(({ value }) => value)
    return shuffled;
}
var shuffledDeck = randomizer();
var drawCardTotal = 0;
    function drawCard(){
    var cardDrawn = shuffledDeck[drawCardTotal];
    console.log(cardDrawn);
    drawCardTotal++;
    var value = cardDrawn.replace(/\D/g, '');
    deckPct = Math.ceil((drawCardTotal / shuffledDeck.length) * 100);
    shoe.innerText = 'Shoe: ' + deckPct +'%'
    if (value >= 2  && value <= 6){
        count++;
        countTrack.innerText = 'Count: '+ count;
    } else if (value <= 11 && value >= 10){
        count--;
        countTrack.innerText = 'Count: '+ count;
    }
    if (deckPct >= 85&& deckPct < 86){
        alert("Let's get ready to Shuufffle!!");
        document.getElementById("shuffleBtn").disabled = false;
    }
    var drawObj = {cardDrawn, value};
    return drawObj;
}
    function playGame(){
    console.log(shuffledDeck);
    if(p3bet !== 0 || p2bet !== 0 || p1bet !== 0){
            document.getElementById("playBtn").disabled = true;
        if(p1bet > 0){
            p1PlayCard1();
        } if(p2bet > 0){
            p2PlayCard1();
        } if(p3bet > 0){
            p3PlayCard1();
        }dDrawCard1();
        if(p1bet > 0){
            p1PlayCard2();
        }
        if(p2bet > 0){
            p2PlayCard2();
        }
        if(p3bet > 0){
            p3PlayCard2();
        }
            dDrawCard2();
document.getElementById("p3BB").disabled = true;
document.getElementById("p2BB").disabled = true;
document.getElementById("p1BB").disabled = true;
    }
} 
            function p1PlayCard1(){
                p1Status = true;
            var p1C1 = drawCard();
            p1Card1.innerText = p1C1.cardDrawn;
            return p1C1;
        }
        function p2PlayCard1(){
                p2Status = true;
            var p2C1 = drawCard();
            p2Card1.innerText = p2C1.cardDrawn;
            return p2C1;
        }
        function p3PlayCard1(){
                p3Status = true;
            var p3C1 = drawCard();
            p3C1Value = p3C1.value;
            p3Card1.innerText = p3C1.cardDrawn;
            return p3C1;
        }
        function dDrawCard1(){
            var dC1 = drawCard();
            dCard1.innerText = dC1.cardDrawn;
            var dTotal = +dC1.value;
            dValue.innerText = 'Dealer Total: '+ dTotal;
            return dTotal;
        }
        function p1PlayCard2(){
            p1EnableBtn()
            var p1PC1 = p1PlayCard1();
            var p1C2 = drawCard();
            p1Card2.innerText = p1C2.cardDrawn;
            var p1Total = +p1PC1.value + +p1C2.value;
            p1CardTotal.innerText = 'Total: '+ p1Total;
            if (p1Total == 22){
                p1Total = 12;
                p1CardTotal.innerText = 'Total: '+ p1Total;
            }
            if (p1Total == 21){
                alert("Player 1 BLACKJACK!");
                p1Pot = p1Pot + (p1bet * 1.5);
                p1potTotal.innerText = 'Pot: ' + p1Pot;
                p1bet = 0;
                p1Status = false;
                p1DisableBtn();
                p1Stand();
            } return p1Total;
        }
        function p2PlayCard2(){
            if (p1Status == false){
                p2EnableBtn();
            }
            var p2PC1 = p2PlayCard1();
            var p2C2 = drawCard();
            p2Card2.innerText = p2C2.cardDrawn;
            var p2Total = +p2PC1.value + +p2C2.value;
            p2CardTotal.innerText = 'Total: '+ p2Total;
            if (p2Total == 22){
                p2Total = 12;
                p2CardTotal.innerText = 'Total: '+ p2Total;
            }
            if (p2Total == 21){
                alert("Player 2 BLACKJACK!");
                p2Pot = p2Pot + (p2bet * 1.5);
                p2potTotal.innerText = 'Pot: ' + p2Pot;
                p2bet = 0;
                p2Status = false;
                p2DisableBtn();
                p2Stand();
            }
        }
        function p3PlayCard2(){
            if (p1Status == false && p2Status == false){
                p3EnableBtn();
            }
            var p3PC1 = p3PlayCard1();
            var p3C2 = drawCard();
            p3Card2.innerText = p3C2.cardDrawn;
            p3C2Value = p3C2.value;
            var p3Total = +p3PC1.value + +p3C2.value;
            p3CardTotal.innerText = 'Total: '+ p3Total;
            if (p3Total == 22){
                p3CardTotal.innerText = 'Total: '+ p3Total;
                p3Total = 12;
            }
            if (p3Total == 21){
                alert("Player 3 BLACKJACK!");
                p3Pot = p3Pot + (p3bet * 1.5);
                p3potTotal.innerText = 'Pot: ' + p3Pot;
                p3bet = 0;
                p3Status = false;
                p3DisableBtn();
                p3Stand();
            }
        }
        function dDrawCard2(){
            dCard2.innerText = '?';
        }
var n = 2;
function p1Hit(){
        document.getElementById("p1DoubleBtn").disabled = true;
        document.getElementById("p1StandBtn").disabled = false;
        document.getElementById("p1HitBtn").disabled = false;
        if (n == 2){
            p1C3F();
        } else if (n == 3){
            p1C4F();
        } else if (n == 4){
            p1C5F();
        } else if (n == 5){
            p1C6F();
        } else if (n == 6){
            p1C7F();
        } else if (n == 7){
            p1C8F();
        }
        n++;
        return n;
}
        function p1C3F(){
            var p1Hitt = drawCard();
            p1Value(p1Hitt.value);
        p1Card3.innerText = p1Hitt.cardDrawn;
        }
        function p1C4F(){
            var p1Hitt = drawCard();
            p1Value(p1Hitt.value);
        p1Card4.innerText = p1Hitt.cardDrawn;
        }
        function p1C5F(){
            var p1Hitt = drawCard();
            p1Value(p1Hitt.value);
        p1Card5.innerText = p1Hitt.cardDrawn;
        }
        function p1C6F(){
            var p1Hitt = drawCard();
            p1Value(p1Hitt.value);
        p1Card6.innerText = p1Hitt.cardDrawn;
        }
        function p1C7F(){
            var p1Hitt = drawCard();
            p1Value(p1Hitt.value);
        p1Card7.innerText = p1Hitt.cardDrawn;
        }
        function p1C8F(){
            var p1Hitt = drawCard();
            p1Value(p1Hitt.value);
        p1Card8.innerText = p1Hitt.cardDrawn;
        }
var e = 2;
function p2Hit(){
    document.getElementById("p2DoubleBtn").disabled = true;
    document.getElementById("p2StandBtn").disabled = false;
    document.getElementById("p2HitBtn").disabled = false;
    if (e == 2){
        p2C3F();
    } else if (e == 3){
        p2C4F();
    } else if (e == 4){
        p2C5F();
    } else if (e == 5){
        p2C6F();
    } else if (e == 6){
        p2C7F();
    } else if (e == 7){
        p2C8F();
    }
    e++;
    return e;
    }
    function p2C3F(){
        var p2Hitt = drawCard();
        p2Value(p2Hitt.value);
    p2Card3.innerText = p2Hitt.cardDrawn;
    }
    function p2C4F(){
        var p2Hitt = drawCard();
        p2Value(p2Hitt.value);
    p2Card4.innerText = p2Hitt.cardDrawn;
    }
    function p2C5F(){
        var p2Hitt = drawCard();
        p2Value(p2Hitt.value);
    p2Card5.innerText = p2Hitt.cardDrawn;
    }
    function p2C6F(){
        var p2Hitt = drawCard();
        p2Value(p2Hitt.value);
    p2Card6.innerText = p2Hitt.cardDrawn;
    }
    function p2C7F(){
        var p2Hitt = drawCard();
        p2Value(p2Hitt.value);
    p2Card7.innerText = p2Hitt.cardDrawn;
    }
    function p2C8F(){
        var p2Hitt = drawCard();
        p2Value(p2Hitt.value);
    p2Card8.innerText = p2Hitt.cardDrawn;
    }
var u = 2;
function p3Hit(){
    document.getElementById("p3DoubleBtn").disabled = true;
    document.getElementById("p3StandBtn").disabled = false;
    document.getElementById("p3HitBtn").disabled = false;
    if (u == 2){
        p3C3F();
    } else if (u == 3){
        p3C4F();
    } else if (u == 4){
        p3C5F();
    } else if (u == 5){
        p3C6F();
    } else if (u == 6){
        p3C7F();
    } else if (u == 7){
        p3C8F();
    }
    u++;
    return u;
}
function p3C3F(){
    var p3Hitt = drawCard();
    p3Value(p3Hitt.value);
p3Card3.innerText = p3Hitt.cardDrawn;
}
function p3C4F(){
    var p3Hitt = drawCard();
    p3Value(p3Hitt.value);
p3Card4.innerText = p3Hitt.cardDrawn;
}
function p3C5F(){
    var p3Hitt = drawCard();
    p3Value(p3Hitt.value);
p3Card5.innerText = p3Hitt.cardDrawn;
}
function p3C6F(){
    var p3Hitt = drawCard();
    p3Value(p3Hitt.value);
p3Card6.innerText = p3Hitt.cardDrawn;
}
function p3C7F(){
    var p3Hitt = drawCard();
    p3Value(p3Hitt.value);
p3Card7.innerText = p3Hitt.cardDrawn;
}
function p3C8F(){
    var p3Hitt = drawCard();
    p3Value(p3Hitt.value);
p3Card8.innerText = p3Hitt.cardDrawn;
}
function p1Stand(){
        document.getElementById("p1DoubleBtn").disabled = true;
        document.getElementById("p1StandBtn").disabled = true;
        document.getElementById("p1HitBtn").disabled = true;
        p1Status = false;
    if (p2bet > 0 && p1Status == false){
        p2EnableBtn();      
    } else if (p3bet > 0 && p1Status == false && p2Status == false){
        p3EnableBtn();
    } 
    if (p2bet == 0 && p3bet == 0){
        dealerDraw();
    }
}
function p2Stand(){
    p2Status = false;
    if(p1bet > 0 || p1Status == false){
        p2DisableBtn();
    }
    if (p3bet > 0 || p3Status == true){
        p3EnableBtn();
    }
    if (p1bet == 0 && p1Status == false && p3bet == 0 && p3Status == false  ){
        dealerDraw();
    }
}
function p3Stand(){
    document.getElementById("p3DoubleBtn").disabled = true;
    document.getElementById("p3StandBtn").disabled = true;
    document.getElementById("p3HitBtn").disabled = true;
    p3Status = false;
    if (p1bet == 0 || p1Status == false && p2Status == false || p2bet == 0){
        dealerDraw();
    }
}
function shuffle(){
    randomizer();
    count = 0;
    drawCardTotal = 0;
    deckPct = 0;
    p1bet = 0;
    p2bet = 0;
    p3bet = 0;
    p1Status = false;
    p2Status = false;
    p3Status = false;
    countTrack.innerText = 'Count: '+ count;
    shoe.innerText = 'Shoe: ' + deckPct +'%';
    document.getElementById("shuffleBtn").disabled = true;
    cleanUp();
    return shuffledDeck;
}
function cleanUp(){
    document.getElementById("p3BB").disabled = false;
    document.getElementById("p2BB").disabled = false;
    document.getElementById("p1BB").disabled = false;
    document.getElementById("playBtn").disabled = false;
    document.getElementById("p1DoubleBtn").disabled = true;
    document.getElementById("p1StandBtn").disabled = true;
    document.getElementById("p1HitBtn").disabled = true;
    document.getElementById("p2DoubleBtn").disabled = true;
    document.getElementById("p2StandBtn").disabled = true;
    document.getElementById("p2HitBtn").disabled = true;
    document.getElementById("p3DoubleBtn").disabled = true;
    document.getElementById("p3StandBtn").disabled = true;
    document.getElementById("p3HitBtn").disabled = true;
    p1bet = 0;
    p2bet = 0;
    p3bet = 0;
    n = 2;
    e = 2;
    u = 2;
    p1Card1.innerText = '';
    p1Card2.innerText = '';
    p1Card3.innerText = '';
    p1Card4.innerText = '';
    p1Card5.innerText = '';
    p1Card6.innerText = '';
    p1Card7.innerText = '';
    p1Card8.innerText = '';
    p1CardTotal.innerText = 'Total: ';
    p1betTotal.innerText = 'Bet: ';
    p2Card1.innerText = '';
    p2Card2.innerText = '';
    p2Card3.innerText = '';
    p2Card4.innerText = '';
    p2Card5.innerText = '';
    p2Card6.innerText = '';
    p2Card7.innerText = '';
    p2Card8.innerText = '';
    p2betTotal.innerText = 'Bet: ';
    p2CardTotal.innerText = 'Total: ';
    p3CardTotal.innerText = 'Total: ';
    p3betTotal.innerText = 'Bet: ';
    p3Card1.innerText = '';
    p3Card2.innerText = '';
    p3Card3.innerText = '';
    p3Card4.innerText = '';
    p3Card5.innerText = '';
    p3Card6.innerText = '';
    p3Card7.innerText = '';
    p3Card8.innerText = '';
    dCard1.innerText = '';
    dCard2.innerText = '';
    dCard3.innerText = '';
    dCard4.innerText = '';
    dCard5.innerText = '';
    dCard6.innerText = '';
    dCard7.innerText = '';
    dCard8.innerText = '';
    dValue.innerText = 'Dealer Total: ';
}
function p1Double(){
    if(p1bet > 0){
        if(p1bet <= p1Pot){
    p1doub = drawCard();
    p1DoubleBet = p1bet * 2;
    p1Pot = p1Pot - p1bet;
    p1potTotal.innerText = 'Pot: ' + p1Pot;
    p1betTotal.innerText = 'Bet: ' + p1DoubleBet;
    p1Card3.innerText = p1doub.cardDrawn;
    p1Status = false;
    let temp = p1CardTotal.textContent;
    var p1ValueF = temp.replace(/\D/g, '');
    p1CardTotal.innerText = (+p1ValueF + +p1doub.value);
    if (p1ValueF > 21){
        p1Bust();
    }
    p1Stand();
    } else {
    alert("You don't Have Enough Chips");
    }
    }
}
function p2Double(){
    if(p2bet > 0){
        if(p2bet <= p2Pot){
        p2doub = drawCard();
    p2DoubleBet = p2bet * 2;
    p2Pot = p2Pot - p2bet;
    p2betTotal.innerText = 'Bet: ' + p2DoubleBet;
    p2potTotal.innerText = 'Pot: ' + p2Pot;
    p2Card3.innerText = p2doub.cardDrawn;
    p2Status = false;
    let temp = p2CardTotal.textContent;
    var p2ValueF = temp.replace(/\D/g, '');
    p2CardTotal.innerText = (+p2ValueF + +p2doub.value);
    if (p2ValueF > 21){
        p2Bust();
    }
    p2Stand();
} else {
    alert("You don't Have Enough Chips");
    }
}
}
function p3Double(){
    if(p3bet > 0){
        if(p3bet <= p3Pot){
        p3doub = drawCard();
    p3DoubleBet = p3bet * 2;
    p3Pot = p3Pot - p3bet;
    p3betTotal.innerText = 'Bet: ' + p3DoubleBet;
    p3potTotal.innerText = 'Pot: ' + p3Pot;
    p3Card3.innerText = p3doub.cardDrawn;
    p3Status = false;
    let temp = p3CardTotal.textContent;
    var p3ValueF = temp.replace(/\D/g, '');
    p3CardTotal.innerText = (+p3ValueF + +p3doub.value);
    if (p3ValueF > 21){
        p3Bust();
    }
    p3Stand();
} else {
    alert("You don't Have Enough Chips");
    }
    }
}
function p1DisableBtn(){
    document.getElementById("p1DoubleBtn").disabled = true;
    document.getElementById("p1StandBtn").disabled = true;
    document.getElementById("p1HitBtn").disabled = true;
}
function p2DisableBtn(){
    document.getElementById("p2DoubleBtn").disabled = true;
    document.getElementById("p2StandBtn").disabled = true;
    document.getElementById("p2HitBtn").disabled = true;
}
function p3DisableBtn(){
    document.getElementById("p3DoubleBtn").disabled = true;
    document.getElementById("p3StandBtn").disabled = true;
    document.getElementById("p3HitBtn").disabled = true;
}
function p1EnableBtn(){
    document.getElementById("p1DoubleBtn").disabled = false;
    document.getElementById("p1StandBtn").disabled = false;
    document.getElementById("p1HitBtn").disabled = false;
}
function p2EnableBtn(){
    document.getElementById("p2DoubleBtn").disabled = false;
    document.getElementById("p2StandBtn").disabled = false;
    document.getElementById("p2HitBtn").disabled = false;
}
function p3EnableBtn(){
    document.getElementById("p3DoubleBtn").disabled = false;
    document.getElementById("p3StandBtn").disabled = false;
    document.getElementById("p3HitBtn").disabled = false;
}
function p1Value(p1Tot){
    let temp = p1CardTotal.textContent;
    var p1ValueF = temp.replace(/\D/g, '');
    p1ValueF = +p1ValueF + +p1Tot;
p1CardTotal.innerText = p1ValueF;
if (p1ValueF > 21){
    p1Bust();
}
}
function p2Value(p2Tot){
    let temp = p2CardTotal.textContent;
    var p2ValueF = temp.replace(/\D/g, '');
    p2ValueF = +p2ValueF + +p2Tot;
p2CardTotal.innerText = p2ValueF;
if (p2ValueF > 21){
    p2Bust();
}
}
function p3Value(p3Tot){
    let temp = p3CardTotal.textContent;
    var p3ValueF = temp.replace(/\D/g, '');
    p3ValueF = +p3ValueF + +p3Tot;
    p3CardTotal.innerText = p3ValueF;
    if (p3ValueF > 21){
        p3Bust();
    }
}
function dValueF(dTot){
    let temp = dValue.textContent;
    var dValueTot = temp.replace(/\D/g, '');
    dValueTot = +dValueTot + +dTot;
    dValue.innerText = dValueTot;
    if (dValueTot > 21){
        dBust();
    }
}
function p1Bust(){
    p1DisableBtn();
    p1bet = 0;
    p1betTotal.innerText = 'Bust';
    p1Status = false;
    if (p2bet > 0 && p1Status == false){
        p2EnableBtn();      
    } else if (p3bet > 0 && p1Status == false && p2Status == false){
        p3EnableBtn();
    }
    if (p3bet == 0 || p3Status == false && p2Status == false || p2bet == 0){
        dealerDraw();
    }
}
function p2Bust(){
    p2DisableBtn();
    p2bet = 0;
    p2betTotal.innerText = 'Bust';
    p2Status = false;
    if (p3bet > 0 || p3Status == true){
        p3EnableBtn();
    }
    if (p1bet == 0 || p1Status == false && p3bet == 0 || p3Status == false ){
        dealerDraw();
    }
}
function p3Bust(){
    p3DisableBtn();
    p3bet = 0;
    p3betTotal.innerText = 'Bust';
    p3Status = false;
    if (p1bet == 0 || p1Status == false && p2Status == false || p2bet == 0){
        dealerDraw();
    }
}
function dealerStop(dH){
    console.log('dealerStop');
    let temp1 = p1CardTotal.textContent;
    var p1ValueF = temp1.replace(/\D/g, '');
    let temp2 = p2CardTotal.textContent;
    var p2ValueF = temp2.replace(/\D/g, '');
    let temp3 = p3CardTotal.textContent;
    var p3ValueF = temp3.replace(/\D/g, '');
    if (dH > p1ValueF && p1ValueF != 0){
        p1Lose();
    } else if (dH < p1ValueF && p1ValueF < 22 && p1bet != 0){
        p1Win();
    } else if (dH == p1ValueF){
        p1Push();
    }
    if (p2ValueF != 0 && dH > p2ValueF && p2bet > 0){
        p2Lose();
    } else if (dH < p2ValueF && p2bet > 0 && p2ValueF < 22 && p2bet != 0){
        p2Win();
    } else if (dH == p2ValueF){
        p2Push();
    }
    if (dH > p3ValueF && p3bet > 0 && p3ValueF != 0){
        p3Lose();
    } else if (dH < p3ValueF && p3bet > 0 && p3ValueF < 22 && p3bet != 0){
        p3Win();
    } else if (dH == p3ValueF){
        p3Push();
    } return dH;
}
function dBust(){
    let play1Value = p1CardTotal.textContent;
    var p1ValueF = play1Value.replace(/\D/g, '');
    let play2Value = p2CardTotal.textContent;
    var p2ValueF = play2Value.replace(/\D/g, '');
    let play3Value = p3CardTotal.textContent;
    var p3ValueF = play3Value.replace(/\D/g, '');
    var dHandBust = dValue.textContent;
    var dHBust = dHandBust.replace(/\D/g, '');
    if (p1ValueF != 0 && p1ValueF < 22 && p1ValueF > dHBust ){
        console.log('dbustF');
        p1Win();
    }
    if (p2ValueF != 0 && p2ValueF <= 21 && p2bet > 0 || p2ValueF != 0 && p2ValueF > dHBust && p2bet > 0){
        p2Win();
    }
    if (p3ValueF != 0 && p3ValueF <= 21 && p3bet > 0 || p3ValueF != 0 && p3ValueF > dHBust && p3bet > 0){
        p3Win();
    }
}
function dealerDraw(){
    document.getElementById("clear").disabled = false;
    if (p1bet == 0 && p2bet == 0 && p3bet == 0){
        bustOut();
        return;
    }else if(p1Status == false && p2Status == false && p3Status == false){
        dC2 = drawCard();
        dCard2.innerText = dC2.cardDrawn;
        let dC2V = dC2.value;
        dVTotal = dValue.textContent;
        dC2Total = dVTotal.replace(/\D/g, '');
        var dHand = +dC2Total + +dC2V;
        dValue.innerText = 'Dealer Total: '+ dHand;
        console.log('dealerDraw');
    }
    if (dHand == 22){
        dHand = 12;
    }
        if (dHand >=17 && dHand<=21){
            console.log('3');
            dealerStop(dHand);
            return;
        }else if (dHand < 17){
            dC3 = drawCard();
            dCard3.innerText = dC3.cardDrawn;
            let dC3V = dC3.value;
            dVTotal = dValue.textContent;
            dC3Total = dVTotal.replace(/\D/g, '');
            dHand = +dHand + +dC3V;
            dValue.innerText = 'Dealer Total: '+ dHand;
            }
            if (dHand > 21){
                dBust();
                return;
            }else if (dHand >=17 && dHand<=21){
            dealerStop(dHand);
            console.log('4');
            return;
            }else if (dHand < 17){
            dC4 = drawCard();
            dCard4.innerText = dC4.cardDrawn;
            let dC4V = dC4.value;
            dVTotal = dValue.textContent;
            dC4Total = dVTotal.replace(/\D/g, '');
            dHand = +dHand + +dC4V;
            dValue.innerText = 'Dealer Total: '+ dHand;
            }
            if (dHand > 21){
                dBust();
                return;
            } else if (dHand >=17 && dHand<=21){
            dealerStop(dHand);
            console.log('5');
            return;
            }else if (dHand < 17){
            dC5 = drawCard();
            dCard5.innerText = dC5.cardDrawn;
            let dC5V = dC5.value;
            dVTotal = dValue.textContent;
            dC5Total = dVTotal.replace(/\D/g, '');
            dHand = +dHand + +dC5V;
            dValue.innerText = 'Dealer Total: '+ dHand;
            }
            if (dHand > 21){
            dBust();
            return;
            }else if (dHand >=17 && dHand<=21){
            dealerStop(dHand);
            console.log('6');
            return;
            }else if (dHand < 17){
            dC6 = drawCard();
            dCard6.innerText = dC6.cardDrawn;
            let dC6V = dC6.value;
            dVTotal = dValue.textContent;
            dC6Total = dVTotal.replace(/\D/g, '');
            dHand = +dHand + +dC6V;
            dValue.innerText = 'Dealer Total: '+ dHand;
            }if (dHand > 21){
                dBust();
                return;
            }else if (dHand >=17 && dHand<=21){
            console.log('7');
            dealerStop(dHand);
            return;
            }else if (dHand < 17){
            dC7 = drawCard();
            dCard7.innerText = dC7.cardDrawn;
            let dC7V = dC7.value;
            dVTotal = dValue.textContent;
            dC7Total = dVTotal.replace(/\D/g, '');
            dHand = +dHand + +dC7V;
            dValue.innerText = 'Dealer Total: '+ dHand;
            if (dHand > 21){
                dBust();
                return;
            } else if (dHand >=17 && dHand<=21){
            console.log('8');
            dealerStop();
            return;
            }else if (dHand < 17){
            dC8 = drawCard();
            dCard8.innerText = dC8.cardDrawn;
            let dC8V = dC8.value;
            dVTotal = dValue.textContent;
            dC8Total = dVTotal.replace(/\D/g, '');
            dHand = +dHand + +dC8V;
            dValue.innerText = 'Dealer Total: '+ dHand;
            }if (dHand > 21){
                dBust();
                return;
            }else if (dHand >=17 && dHand<=21){
                console.log('8');
                dealerStop();
                return;
            }
        }
    }
function bustOut(){
        console.log('bustout');
        dC2 = drawCard();
        dCard2.innerText = dC2.cardDrawn;
        var dHBO = dValue.textContent;
        var dHBOV = dHBO.replace(/\D/g, '');
        dValue.innerText = "Dealer Total:" + (+dC2.value + +dHBOV);
}
function p1Win(){
    console.log('p1Win');
    var play1bet = p1betTotal.textContent;
    var p1betF = play1bet.replace(/\D/g, '');
    var p1PTC = p1potTotal.textContent;
    var p1PT = p1PTC.replace(/\D/g, '');
    p1Pot = (p1Pot + (+p1betF * 2));
    p1potTotal.innerText = "Pot: " + p1Pot;
    p1betTotal.innerText = 'W: '+ (+p1betF *2);
    p1bet = 0;
}
function p2Win(){
    console.log('p2Win');
    var play2bet = p2betTotal.textContent;
    var p2betF = play2bet.replace(/\D/g, '');
    var p2PTC = p2potTotal.textContent;
    var p2PT = p2PTC.replace(/\D/g, '');
    p2Pot = (p2Pot + (+p2betF * 2));
    p2potTotal.innerText = "Pot: " + p2Pot;
    p2betTotal.innerText = 'W: '+ (+p2betF *2);
    p2bet = 0;
}
function p3Win(){
    console.log('p3Win');
    var play3bet = p3betTotal.textContent;
    var p3betF = play3bet.replace(/\D/g, '');
    var p3PTC = p3potTotal.textContent;
    var p3PT = p3PTC.replace(/\D/g, '');
    p3Pot = (p3Pot + (+p3betF * 2));
    p3potTotal.innerText = "Pot: " + p3Pot;
    p3betTotal.innerText = 'W: '+ (+p3betF *2);
    p3bet = 0;
}
function p1Lose(){
    p1bet = 0;
    p1betTotal.innerText = 'L'
}
function p2Lose(){
    p2bet = 0;
    p2betTotal.innerText = 'L'
}
function p3Lose(){
    p3bet = 0;
    p3betTotal.innerText = 'L'
}
function p1Push(){
    var play1bet = p1betTotal.textContent;
    var p1betF = play1bet.replace(/\D/g, '');
    p1Pot = p1Pot + +p1betF;
    p1betTotal.innerText = 'PUSH';
    p1potTotal.innerText = "Pot: " + p1Pot;
    p1bet = 0;
}
function p2Push(){
    var play2bet = p2betTotal.textContent;
    var p2betF = play2bet.replace(/\D/g, '');
    p2Pot = p2Pot + +p2betF;
    p2betTotal.innerText = 'PUSH';
    p2potTotal.innerText = "Pot: " + p2Pot;
    p2bet = 0;
}
function p3Push(){
    var play3bet = p3betTotal.textContent;
    var p3betF = play3bet.replace(/\D/g, '');
    p3Pot = p3Pot + +p3betF;
    p3betTotal.innerText = 'PUSH';
    p3potTotal.innerText = "Pot: " + p3Pot;
    p3bet = 0;
}
function shadow(element){
    element.classList.add("shadow");
}
function removeShadow(element){
    element.classList.remove("shadow");
}
function shadow2(element){
    element.classList.add("shadow2");
}
function removeShadow2(element){
    element.classList.remove("shadow2");
}